import os
os.system('sudo apt install gcc cython3 python-pip3 python3-lxml')
