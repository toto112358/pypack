import os
os.system('sudo rm /usr/bin/py2elf')
