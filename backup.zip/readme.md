# PYPACK !!!

To do:
------
1. Merge everything into the pypack script
2. Add a read me
    - Documentation
    - Fast [cheat sheet](cheat_sheet.md)
3. Create a Makefile
4. Make pypack **fool-proof**
5. Ask community to make commits on my script
6. Add support for python3 project that need MULTIPLE files
7. Add some VIM propaganda in easter eggs




